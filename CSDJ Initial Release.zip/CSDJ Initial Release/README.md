#### CSDJ- An app meant to play Music in Source Games like CSGO
#### Contributors- sarthak247(Sarthak Thakur), gopal-kaul(Gopal Kaul)
#### Initial release V1.0
#### Only CLI interface and one song at a time

This is the initial release of CSDJ!

Important things to do before running it - 
1) Open up csdj.cfg and copy your Counter Strike Global Offensive or other Source Game Directory Location
Example - C:\Program Files\Steam\steamapps\common\Counter Strike-Global Offensive
or /home/ubuntu/.steam/steamapps/commmon/Counter Strike-Global Offensive

2) Copy csmusic to your Counter Strike-Global Offensive\csgo\cfg directory as it is.

3) Profit!

How to use the app-
Double click on the csdj.exe file.
Enter your song name, it will automatically search it from YouTube, download it and copy it to the folder!
In game, run "exec csmusic" in console.
While in game, press '/' to auto play the music, or "'" to push to play music.

Feel free to star, watch this repository for an updated version with GUI soon!