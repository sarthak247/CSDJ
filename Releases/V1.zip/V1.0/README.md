#### CSDJ- An app meant to play Music in Source Games like CSGO
#### Contributors- sarthak247(Sarthak Thakur), gopal-kaul(Gopal Kaul)
#### Initial release V1.0
#### Only CLI interface and one song at a time

This is the initial release of CSDJ!

How to use the app-
Double click on the csdj.exe file.
Enter your song name, it will automatically search it from YouTube, download it and copy it to the folder!
For the first run, it will ask you to paste your CSGO install directory. Paste it till the CSGO folder.
Example:
C:\Program Files(x86)\Steam\steamapps\common\Counter-Strike Global Offensive
~/.steam/steamapps/common/Counter-Strike Global Offensive

In game, run "exec csdj" in console.
While in game, press '/' to auto play the music, or "'" to push to play music.

Feel free to star, watch this repository for an updated version with GUI soon!